# Import necessary modules and classes
from card import Card
from deck import Deck
from player import Player
from dealer import Dealer
import check_input
#Name: Abdurrahman Mohamed
#Name: Riley Stolarz
#Date: 10/4/2023
#Desc: Plays the game "Blackjack" with a Player and a Dealer.
# Define the display_winner function
def display_winner(pScore, dScore, points):
  if pScore < dScore:
    print("Dealer wins.")
    points[1] += 1
  elif dScore < pScore:
    print("Player wins.")
    points[0] += 1
  elif pScore == dScore:
    print("Tie.")
  print(f"Player's points: {points[0]}\nDealer's points: {points[1]}")

# Main game loop
def main():
    print("-Blackjack-")

    # Initialize points for the player and dealer
    player_points = 0
    dealer_points = 0
    points = [player_points, dealer_points]

    #initialize new deck
    deck = Deck()
    deck.shuffle()
    # Main game loop
    while True:
        # Create and shuffle a new deck
        if len(deck) <= 12:
          deck = Deck()
          deck.shuffle()

        # Create a player and deal two cards
        player = Player(deck)
        print("\nPlayer's Cards:")
        print(player)
        print(f"Score: {player.score()}")
        # Player's turn
        while True:
            # Ask the player if they want to hit or stay
            choice = check_input.get_int_range("1. Hit\n2. Stay\nEnter Choice: ", 1, 2)

            if choice == 1:
                player.hit()
                print("\nPlayer's Turn:")
                print(player)
                print(f"Score: {player.score()}")

                # Check if the player busts
                if player.score() > 21:
                    print("Bust!")
                    break
            else:
                break

        # Dealer's turn
        dealer = Dealer(deck)
        dealer_result = dealer.play()
        print(dealer_result)

        # Determine the winner and update points
        p_score = player.score() if player.score() <= 21 else 0
        d_score = dealer.score() if dealer.score() <= 21 else 0
        display_winner(p_score, d_score, points)

        # Ask if the player wants to play another round
        play_again = check_input.get_yes_no("Play again? (Y/N): ")
        if not play_again:
            print("Thanks for playing!")
            break


if __name__ == "__main__":
    main()
