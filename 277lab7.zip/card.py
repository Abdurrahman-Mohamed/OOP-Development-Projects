class Card:
    def __init__(self, suit, rank): #initializes card class
        self._rank = rank
        self._suit = suit

    @property
    def rank(self):
        return self._rank

    def __str__(self): #string format
        ranks = ["2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"]
        suits = ["Clubs", "Diamonds", "Hearts", "Spades"]
        return f"{ranks[self._rank]} of {suits[self._suit]}"

    def __lt__(self, other): #less than operation
        return self._rank < other._rank
