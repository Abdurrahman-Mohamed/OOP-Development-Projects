# main.py
#Name: Abdurrahman Mohamed
#Name: Riley Stolarz
#Date: 9/25/2023
#Desc: Generates a task list.
from tasklist import Tasklist # Import the Tasklist class from the tasklist module.
import check_input # Import the check_input module, presumably containing input validation functions.

# Define the main_menu function to display the menu options and get user input.
def main_menu(tl):
    print("\n-Tasklist-")
    print(f"-Tasklist-\nTasks to complete: {tl}")
    print("1. Display current task")
    print("2. Display all tasks")
    print("3. Mark current task complete")
    print("4. Add new task")
    print("5. Save and quit")
    return check_input.get_int_range("Enter your choice (1-5): ", 1, 5)

def get_date(): # Define a function to get a date input from the user.
    year = check_input.get_int_range("Enter year (2000-3000): ", 2000, 3000)
    month = check_input.get_int_range("Enter month (1-12): ", 1, 12)
    day = check_input.get_int_range("Enter day (1-31): ", 1, 31)
    return f"{month:02d}/{day:02d}/{year}"

def get_time():# Define a function to get a time input from the user.
    hour = check_input.get_int_range("Enter hour (0-23): ", 0, 23)
    minute = check_input.get_int_range("Enter minute (0-59): ", 0, 59)
    return f"{hour:02d}:{minute:02d}"

def main():# Define the main function where the program execution starts.
    tasklist = Tasklist() # Create an instance of the Tasklist class to manage tasks.

    while True:
      tl = len(tasklist)  
      choice = main_menu(tl) # Get the user's choice from the main menu.
      if choice == 1: # Display current task
          if len(tasklist) > 0:
              print(tasklist[0])
          else:
              print("All tasks are complete.")
      elif choice == 2: # Display all tasks
          if len(tasklist) > 0:
              for index, task in enumerate(tasklist, start=1):
                  print(f"{index}. {task}")
          else:
              print("All tasks are complete.")
      elif choice == 3: # Mark current task complete
          if len(tasklist) > 0:
              completed_task = tasklist.mark_complete()
              print(f"Marked complete: {completed_task}")
          else:
              print("All tasks are complete.")
      elif choice == 4:  # Add new task
          desc = input("Enter task description: ")
          date = get_date()
          time = get_time()
          tasklist.add_task(desc, date, time)
          print("Task added successfully.")
      elif choice == 5: # Save and quit
          tasklist.save_file()
          print("Tasks saved. Goodbye!")
          break # Exit the loop and end the program.
# Check if this script is the main entry point.
if __name__ == "__main__":
    main() # Call the main function to start the program.
