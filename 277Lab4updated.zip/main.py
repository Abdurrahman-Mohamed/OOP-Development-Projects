import check_input
#Name: Abdurrahman Mohamed
#Date: 9/11/2023
#Desc: Generates a maze for the player to solve.
def read_maze():
  file = open("maze.txt") #change file to swap mazes
  maze = []
  for row in file:
      row_list = []
      for item in row:
          if item != '\n':
              row_list.append(item)
      maze.append(row_list)
  return maze  # Return the maze as a 2D list

def find_start(maze):
    for row_index, row in enumerate(maze):
        for col_index, cell in enumerate(row):
            if cell == 's':
                return [row_index, col_index]

# Function to display the maze with the current location
def display_maze(maze, loc):
    row, col = loc
    for i, row in enumerate(maze):
        for j, cell in enumerate(row):
            if [i, j] == loc:
                print('X', end='')
            else:
                print(cell, end='')
        print()  # Move to the next row
# Main function
def main():
  print("-Maze Solver-")
  maze = read_maze()
  start_location = find_start(maze) # Find the starting location 's' in the maze
  current_location = start_location
  while True:
    display_maze(maze, current_location) # Display the maze with the current location
    print("1. Go North\n2. Go South\n3. Go East\n4. Go West")
    user_input = check_input.get_int_range("Enter Choice: ", 1, 4)
    row, col = current_location
    if user_input == 1:
        new_row = row - 1 # Calculate the new row position for moving North
        new_col = col
    elif user_input == 2:
        new_row = row + 1 # Calculate the new row position for moving South
        new_col = col
    elif user_input == 4:
        new_row = row
        new_col = col - 1 # Calculate the new row position for moving West
    elif user_input == 3:
        new_row = row
        new_col = col + 1 # Calculate the new row position for moving East
    else:
        continue # If an invalid choice is made, go back to the loop start
    if maze[new_row][new_col] != '*':
        current_location = [new_row, new_col] # Update the current location if it's not a wall
    else:
      print("You cannot move there.")

    if maze[new_row][new_col] == 'f':
        display_maze(maze, current_location) # Display the maze with the final location
        print("Congratulations! You solved the maze.")
        break # Exit the loop when the final location 'f' is reached
# Run the main function when the script is executed
main()