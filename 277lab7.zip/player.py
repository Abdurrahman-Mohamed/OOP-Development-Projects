from card import Card

class Player:
    def __init__(self, deck):
        self._deck = deck
        self._hand = []

        # Deal two cards to the player's hand
        for _ in range(2):
            self._hand.append(deck.draw_card())
        # Sort the hand to make it easier to calculate the score
        self._hand.sort()

    def hit(self):
        # Add another card from the deck to the player's hand and resort them
        card = self._deck.draw_card()
        if card is not None:
            self._hand.append(card)
            self._hand.sort()

    def score(self):
        total_score = 0
        num_aces = 0

        # Calculate the score of the hand
        for card in self._hand:
            if card.rank in [9, 10, 11]:  # Jack, Queen, King
                total_score += 10
            elif card.rank == 12:  # Ace
                total_score += 11
                num_aces += 1
            else:
                total_score += card.rank + 2

        # Adjust for aces if the total score is over 21
        while num_aces > 0 and total_score > 21:
            total_score -= 10
            num_aces -= 1

        return total_score

    def __str__(self):
        return "\n".join([str(card) for card in self._hand])
