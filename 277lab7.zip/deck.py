from card import Card
import random

class Deck:
    def __init__(self): #initializes deck class + draws 2 starting cards
        self._cards = []
        for suit in range(4):
            for rank in range(13):
                self._cards.append(Card(suit, rank))

    def shuffle(self): #shuffles cards in deck
        random.shuffle(self._cards)

    def draw_card(self): #takes top card from deck, returns to player then remove it
        if len(self._cards) > 0:
            return self._cards.pop()
        else:
            return None

    def __len__(self): #initializes len() for deck
        return len(self._cards)
