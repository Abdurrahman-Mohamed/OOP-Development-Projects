from player import Player

class Dealer(Player):
    def play(self): #does dealer's full turn, adds strings to result as it plays out
      result = ""
      result += f"\nDealer's Cards:\n{str(self)}\nScore: {self.score()}\n"
      while self.score() <= 16:
        if self.score() <= 21:
          result += "Dealer Hits!\n"  
          super().hit() #uses hit function from player class
          result += f"\nDealer's Cards:\n{str(self)}\nScore: {self.score()}\n"
          if self.score() > 21:
            result += "Bust!"
      return result
