import random

cash = 100

while True:
    print("\n---------Three Card Monte---------")
    print("1. Play")
    print("2. Quit")
    choice = int(input("-> Enter Option : "))

    if choice == 1:
        ch = ['K', 'K', 'K']
        print(f"\nYou have: ${cash}")
        bet = float(input("How much you wanna bet : $"))
        print("\n-----CARDS-----")
        print("|X| |X| |X|")

        loc = random.randint(0, 2)
        ch[loc] = 'Q'

        guess = int(input("\nGuess where QUEEN is at : "))

        if ch[guess - 1] == 'Q':
            cash += bet
            print(f"\nYou WON!! Now You have : {cash}")
            for card in ch:
                print(f" |{card}|", end="")
        else:
            cash -= bet
            print(f"\nYou LOSS!! Now You have : {cash}")
            for card in ch:
                print(f" |{card}|", end="")
    else:
        break
