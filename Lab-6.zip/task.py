# task.py
class Task:
    def __init__(self, desc, date, time):
        self.description = desc
        self.date = date
        self.time = time

    def __str__(self):
        return f"{self.description} - Due: {self.date} {self.time}"

    def __repr__(self):
        return f"{self.description},{self.date},{self.time}"

    def __lt__(self, other):
        selfm, selfd, selfy = self.date[0:2], self.date[3:5], self.date[6:]
      otherm, otherd, othery = other.date[0:2], other.date[3:5], other.date[6:]
      selfTime, otherTime = self.time, other.time
      return (selfy, selfm, selfd, selfTime, self.description) < (othery, otherm, otherd, otherTime, other.description)
