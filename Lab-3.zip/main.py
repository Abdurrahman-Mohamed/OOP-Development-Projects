import random

def roll_dice():
    return sorted([random.randint(1, 6) for _ in range(5)], reverse=True)

def display_dice(name, dice):
    print(f"{name} = {' '.join(map(str, dice))}")

def find_winner(player_points):
    player1_score, player2_score = player_points
    print("Score:")
    print(f"Player #1 = {player1_score}")
    print(f"Player #2 = {player2_score}")
    if player1_score > player2_score:
        print("Player #1 won!")
    elif player2_score > player1_score:
        print("Player #2 won!")
    else:
        print("It's a tie!")

def play_game():
    player_points = [0, 0]

    for player in range(2):
        print(f"- Player #{player + 1}'s Turn -")
        keep = []
        roll = []

        for roll_num in range(3):
            input("Press Enter to roll the dice...")
            dice = roll_dice()
            roll += dice
            display_dice("Roll", dice)

            for value in [6, 5, 4]:
                if value not in keep and value in dice:
                    keep.append(value)
                    print(f"Yo ho ho! Ye secured a {value}!")

            display_dice("Keep", keep)

            if len(keep) == 3:
                cargo = [d for d in roll if d not in keep]
                display_dice("Cargo", cargo)
                cargo_score = sum(cargo)
                print(f"Your cargo points are: {cargo_score}")
                player_points[player] += cargo_score
                break

        print(f"Player #{player + 1} points = {player_points[player]}")
        print()

    find_winner(player_points)

if __name__ == "__main__":
    print("- Ship, Captain, and Crew! -")
    play_game()
